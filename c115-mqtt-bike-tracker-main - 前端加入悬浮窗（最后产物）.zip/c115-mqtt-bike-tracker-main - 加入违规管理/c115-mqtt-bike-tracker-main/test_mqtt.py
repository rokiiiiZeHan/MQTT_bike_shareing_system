import paho.mqtt.client as mqtt

BROKER = "test.mosquitto.org"
PORT = 1883
TOPIC = "bike/gps/update/cuh405_demo_2026"

def on_connect(client, userdata, flags, rc, properties=None):
    print(f"连接结果码: {rc}")
    if rc == 0:
        print("✅ 连接成功！")
        client.subscribe(TOPIC)
        print(f"✅ 已订阅: {TOPIC}")
    else:
        print(f"❌ 连接失败, 错误码: {rc}")

def on_subscribe(client, userdata, mid, reasonCodes, properties=None):
    print(f"✅ 订阅确认, mid={mid}")

def on_message(client, userdata, msg):
    print(f"📨 收到消息！")
    print(f"   主题: {msg.topic}")
    print(f"   内容: {msg.payload.decode()}")

def on_disconnect(client, userdata, rc, properties=None):
    print(f"⚠️ 断开连接, 原因码: {rc}")

print("启动 MQTT 测试...")
client = mqtt.Client(protocol=mqtt.MQTTv5)
client.on_connect = on_connect
client.on_subscribe = on_subscribe
client.on_message = on_message
client.on_disconnect = on_disconnect

print(f"正在连接 {BROKER}:{PORT} ...")
client.connect(BROKER, PORT, 60)
print("进入消息循环，等待消息...")
client.loop_forever()